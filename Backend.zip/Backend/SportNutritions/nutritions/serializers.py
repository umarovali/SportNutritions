# serializers.py

from rest_framework import serializers
from .models import Nutritions, Brand, Category, Goals

class BrandSerializer(serializers.ModelSerializer):
    image = serializers.URLField(required=True)  

    class Meta:
        model = Brand
        fields = ['id', 'name', 'image']

class CategorySerializer(serializers.ModelSerializer):
    image = serializers.URLField(required=True) 

    class Meta:
        model = Category
        fields = ['id', 'name', 'image']

class GoalsSerializer(serializers.ModelSerializer):
    image = serializers.URLField(required=True)  

    class Meta:
        model = Goals
        fields = ['id', 'name', 'image']

# Сериализатор для записи
class NutritionsSerializer(serializers.ModelSerializer):
    brand = serializers.PrimaryKeyRelatedField(queryset=Brand.objects.all())
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())
    goal = serializers.PrimaryKeyRelatedField(queryset=Goals.objects.all())
    image = serializers.URLField(required=True)  

    class Meta:
        model = Nutritions
        fields = ['id', 'name', 'price', 'brand', 'category', 'goal', 'image']

# Сериализатор для чтения
class NutritionsReadSerializer(serializers.ModelSerializer):
    brand = BrandSerializer()
    category = CategorySerializer()
    goal = GoalsSerializer()
    image = serializers.URLField(required=True)  

    class Meta:
        model = Nutritions
        fields = ['id', 'name', 'price', 'brand', 'category', 'goal', 'image']