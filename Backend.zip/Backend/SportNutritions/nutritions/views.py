from rest_framework import generics
from .models import Nutritions, Brand, Category, Goals
from .serializers import NutritionsSerializer, BrandSerializer, CategorySerializer, GoalsSerializer, NutritionsReadSerializer

# Nutritions Views
class NutritionsCreateView(generics.CreateAPIView):
    queryset = Nutritions.objects.all()
    serializer_class = NutritionsSerializer  # Используется для записи

class NutritionsListView(generics.ListAPIView):
    serializer_class = NutritionsReadSerializer

    def get_queryset(self):
        queryset = Nutritions.objects.all()
        
        brand = self.request.query_params.get('brand')
        category = self.request.query_params.get('category')
        goal = self.request.query_params.get('goal')

        if brand:
            queryset = queryset.filter(brand=brand)
        if category:
            queryset = queryset.filter(category=category)
        if goal:
            queryset = queryset.filter(goal=goal)

        return queryset

class NutritionsDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Nutritions.objects.all()
    
    # Используем разные сериализаторы для чтения и записи
    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return NutritionsReadSerializer  # Для чтения
        return NutritionsSerializer  # Для записи

# Brand Views
class BrandCreateView(generics.CreateAPIView):
    queryset = Brand.objects.all()
    serializer_class = BrandSerializer

class BrandListView(generics.ListAPIView):
    queryset = Brand.objects.all()
    serializer_class = BrandSerializer

class BrandDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Brand.objects.all()
    serializer_class = BrandSerializer

# Category Views
class CategoryCreateView(generics.CreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class CategoryListView(generics.ListAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class CategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

# Goals Views
class GoalsCreateView(generics.CreateAPIView):
    queryset = Goals.objects.all()
    serializer_class = GoalsSerializer

class GoalsListView(generics.ListAPIView):
    queryset = Goals.objects.all()
    serializer_class = GoalsSerializer

class GoalsDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Goals.objects.all()
    serializer_class = GoalsSerializer